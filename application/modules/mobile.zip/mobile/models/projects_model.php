<?php

class Projects_model extends CI_Model 
{
	
	
	/*
	*	Retrieve all projects of a user
	*
	*/
	public function getregisteredlaboreres()
	{
		$this->db->where('tenant_id > 0 ');
		$query = $this->db->get('tenants');
		
		return $query;
	}
}